import math
import json
import streamlit as st

class RealEstateProfitabilityCalculator:
    def __init__(self, purchase_price, gross_rent, vacancy_rate,
                 loan_amount, interest_rate, amortization_years,
                 notary_fee, financing_fee, inspection_fee, environmental_study_fee,
                 property_tax, insurance, maintenance, management_fees):

        self.purchase_price = purchase_price
        self.gross_rent = gross_rent
        self.vacancy_rate = vacancy_rate

        # Acquisition costs
        self.notary_fee = notary_fee
        self.financing_fee = financing_fee
        self.inspection_fee = inspection_fee
        self.environmental_study_fee = environmental_study_fee

        # Operating expenses
        self.property_tax = property_tax
        self.insurance = insurance
        self.maintenance = maintenance
        self.management_fees = management_fees

        self.operating_expenses = self.calculate_total_operating_expenses()

        self.loan_amount = loan_amount
        self.interest_rate = interest_rate
        self.amortization_years = amortization_years

    def calculate_total_acquisition_cost(self):
        return (self.purchase_price + self.notary_fee + self.financing_fee +
                self.inspection_fee + self.environmental_study_fee)

    def calculate_total_operating_expenses(self):
        return (self.property_tax + self.insurance +
                self.maintenance + self.management_fees)

    def calculate_net_income(self):
        effective_gross_income = self.gross_rent * (1 - self.vacancy_rate)
        net_operating_income = effective_gross_income - self.operating_expenses
        return net_operating_income

    def calculate_annual_debt_service(self):
        r = self.interest_rate / 12
        n = self.amortization_years * 12
        monthly_payment = self.loan_amount * r / (1 - (1 + r) ** -n)
        return monthly_payment * 12

    def calculate_cash_flow(self):
        noi = self.calculate_net_income()
        debt_service = self.calculate_annual_debt_service()
        return noi - debt_service

    def calculate_cap_rate(self):
        noi = self.calculate_net_income()
        return noi / self.calculate_total_acquisition_cost()

    def calculate_dscr(self):
        noi = self.calculate_net_income()
        debt_service = self.calculate_annual_debt_service()
        return noi / debt_service if debt_service != 0 else float('inf')

    def report(self):
        return {
            "Total Acquisition Cost": self.calculate_total_acquisition_cost(),
            "Total Operating Expenses": self.operating_expenses,
            "Net Operating Income": self.calculate_net_income(),
            "Annual Debt Service": self.calculate_annual_debt_service(),
            "Cash Flow": self.calculate_cash_flow(),
            "Cap Rate": self.calculate_cap_rate(),
            "DSCR": self.calculate_dscr()
        }

# Streamlit app
st.title("Real Estate Profitability Calculator")

with st.form("Input Form"):
    purchase_price = st.number_input("Purchase Price", value=1000000)
    gross_rent = st.number_input("Gross Rent (Annual)", value=120000)
    vacancy_rate = st.number_input("Vacancy Rate (%)", value=5.0) / 100
    loan_amount = st.number_input("Loan Amount", value=700000)
    interest_rate = st.number_input("Interest Rate (%)", value=5.0) / 100
    amortization_years = st.number_input("Amortization (Years)", value=25)

    st.subheader("Acquisition Costs")
    notary_fee = st.number_input("Notary Fee", value=5000)
    financing_fee = st.number_input("Financing Fee", value=7000)
    inspection_fee = st.number_input("Inspection Fee", value=1500)
    environmental_study_fee = st.number_input("Environmental Study Fee", value=3000)

    st.subheader("Operating Expenses (Annual)")
    property_tax = st.number_input("Property Tax", value=12000)
    insurance = st.number_input("Insurance", value=5000)
    maintenance = st.number_input("Maintenance", value=8000)
    management_fees = st.number_input("Management Fees", value=6000)

    submitted = st.form_submit_button("Calculate")

if submitted:
    calculator = RealEstateProfitabilityCalculator(
        purchase_price, gross_rent, vacancy_rate,
        loan_amount, interest_rate, amortization_years,
        notary_fee, financing_fee, inspection_fee, environmental_study_fee,
        property_tax, insurance, maintenance, management_fees
    )
    result = calculator.report()
    st.subheader("📊 Results")
    st.json(result)