# Real Estate Profitability Calculator 🏢

This Streamlit web app helps you evaluate the profitability of income-producing real estate by calculating:

- Acquisition Costs
- Operating Expenses
- Net Operating Income (NOI)
- Cash Flow
- Cap Rate
- Debt Service Coverage Ratio (DSCR)

## 🚀 How to Use

1. Clone or upload this repo to [Streamlit Cloud](https://streamlit.io/cloud)
2. Make sure the main file is `real_estate_app.py`
3. Add a `requirements.txt` with:

   ```
   streamlit>=1.25.0
   ```

4. Deploy and explore your results instantly!

## 📊 Made for Developers, Brokers & Investors
